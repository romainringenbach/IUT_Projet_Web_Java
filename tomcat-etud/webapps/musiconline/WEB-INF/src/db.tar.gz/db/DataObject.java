package db;

public interface DataObject {


}  
